import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

import { Subscription } from "rxjs";
import { HeaderService } from "../../../header.service";
import { FieldsService } from "../../../@core/mock/fields.service";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormArray,
  FormControl,
} from "@angular/forms";
import { IDropdownSettings } from "ng-multiselect-dropdown";
import { TypeService } from "../../../@core/mock/type.service";
@Component({
  selector: "ngx-edit-field",
  templateUrl: "./edit-field.component.html",
  styleUrls: ["./edit-field.component.scss"],
})
export class EditFieldComponent implements OnInit {
  fieldsArray: any = [];
  label: string;
  type: string;
  operat = "";
  Form: FormGroup;
  private routeSub: Subscription;
  dropdownList = [];
  dropdownSettings: IDropdownSettings = {};
  dropdownSettingsForValidation: IDropdownSettings = {};
  typeArray = [];
  types = [];
  validationArray = [];
  selectedValidation = [];
  selectedGroups = [];
  operators = [];
  IsEditable: boolean;
  IsExportable: boolean;
  fieldData = [];
  searchArray = [];

  constructor(
    private fb: FormBuilder,
    private headerService: HeaderService,
    private route: ActivatedRoute,
    private fieldsService: FieldsService
  ) {
    this.getData();
    this.getFields();
    this.getValidations();
  }

  ngOnInit(): void {
    this.fieldsService.getFieldTypes().subscribe((res) => {
      this.typeArray = res["data"]["result"]["types"];
      for (let i = 0; i < this.typeArray.length; i++) {
        if (this.selectedGroups.length !== 0) {
          if (this.typeArray[i].type === "fieldGroup") {
            this.types.push(this.typeArray[i]);
          }
        } else {
          if (this.typeArray[i].type === "field") {
            this.types.push(this.typeArray[i]);
          }
        }
      }
    });

    this.operators = [
      { name: "add" },
      { name: "subtract" },
      { name: "multiply" },
      { name: "divide" },
      { name: "equal" },
      { name: "function" },
    ];
    this.fieldData = [{ name: "constant" }, { name: "field" }];

    this.dropdownSettings = {
      idField: "_id",
      textField: "label",
      enableCheckAll: false,
      noDataAvailablePlaceholderText: "There is no item availabale to show",
      allowSearchFilter: true,
    };
    this.dropdownSettingsForValidation = {
      idField: "_id",
      textField: "name",
      enableCheckAll: false,
      noDataAvailablePlaceholderText: "There is no item availabale to show",
      allowSearchFilter: true,
    };
    this.Form = this.fb.group({
      label: [""],
      type: [""],
      keyName: [""],
      options: this.fb.array([]),
      groups: this.selectedGroups,
      validations: this.selectedValidation,
      operator: this.operat,
      isEditable: this.IsEditable,
      variables: this.fb.array([]),
      isExportable: this.IsExportable,
    });
  }

  variables(): FormArray {
    return this.Form.get("variables") as FormArray;
  }

  newVar(): FormGroup {
    return this.fb.group({
      type: "",
      value: "",
    });
  }

  addVar() {
    this.variables().push(this.newVar());
    this.Form.patchValue(this.fieldsArray);
  }
  removeVar(stepIndex: number) {
    this.variables().removeAt(stepIndex);
  }

  options(): FormArray {
    return this.Form.get("options") as FormArray;
  }
  newOptions(): FormGroup {
    return this.fb.group({
      key: [""],
      value: [""],
    });
  }
  addQuantity() {
    this.options().push(this.newOptions());
    this.Form.patchValue(this.fieldsArray);
  }
  removeQuantity(stepIndex: number) {
    this.options().removeAt(stepIndex);
  }

  onSelect(event) {}
  getData() {
    this.routeSub = this.route.params.subscribe((params) => {
      //log the value of id
      this.fieldsService.getFieldsByKeyName(params["key"]).subscribe(
        (res) => {
          this.fieldsArray = res["data"]["result"];
          this.selectedGroups = this.fieldsArray.groups;
          this.selectedValidation = this.fieldsArray.validations;
          if (res["data"]["result"].expression !== null) {
            this.operat = res["data"]["result"].expression.operator;
          }
          this.IsEditable = res["data"]["result"].isEditable;
          this.IsExportable = res["data"]["result"].isExportable;
          this.Form.patchValue(this.fieldsArray);

          if (this.fieldsArray.options.length > 0) {
            this.fieldsArray.options.forEach((element) => {
              this.addQuantity();
            });
          }

          if (res["data"]["result"].type) {
            this.type = res["data"]["result"].type;
          }

          if (this.fieldsArray.expression !== null) {
            this.fieldsArray.expression.variables.forEach((element) => {
              (this.Form.get("variables") as FormArray).push(
                this.fb.group({
                  type: element["type"],
                  value: element["value"],
                })
              );
            });
          }
          /*   this.fieldsArray.forEach((element) => {
      (this.Form.get('options') as FormArray).push(this.fb.group({
       option:element['option']
     }));
   });  */
          
          this.label = res["data"]["result"].label;
          this.type = res["data"]["result"].type;
         
        },
        (err) => {
          this.headerService.showToast(
            "danger",
            "Workflow",
            "unable to load data"
          );
        }
      );
    });
  }

  save() {
    let validArray = [];
    let groupArray = [];
    validArray = this.Form.value.validations;
    groupArray = this.Form.value.groups;

    this.Form.value.groups = groupArray;
    if (this.Form.value.label === "" || this.Form.value.dataType == "") {
      this.Form.value.label = this.label;
      this.Form.value.type = this.type;
    }

    this.Form.value.keyName = this.fieldsArray.keyName;

    if (groupArray.length > 0) {
      this.Form.value.groups = [];
      for (let i = 0; i < groupArray.length; i++) {
        

        this.Form.value.groups.push(groupArray[i]._id);
      }
    } else {
      this.Form.value.groups = [];
    }

    if (validArray.length > 0) {
      this.Form.value.validations = [];
      for (let i = 0; i < validArray.length; i++) {
        this.Form.value.validations.push(validArray[i]._id);
      }
    } else {
      this.Form.value.validations = [];
    }

    const obj1 = {
      operator:
        this.operat === null || this.operat === ""
          ? this.Form.value.operator
          : this.operat,
      variables:
        this.Form.value.variables.length !== 0
          ? this.Form.value.variables
          : null,
    };

    const obj = {
      label: this.Form.value.label,
      type: this.Form.value.type,
      options: this.Form.value.options,
      groups: this.Form.value.groups,
      validations: this.Form.value.validations,
      isEditable: this.Form.value.isEditable,
      isExportable: this.Form.value.isExportable,
      keyName: this.fieldsArray.keyName,
      expression: obj1.operator !== "" || obj1.variables !== null ? obj1 : null,
    };

    

    this.fieldsService.postFields(obj).subscribe(
      (res) => {
        

        this.headerService.showToast(
          "success",
          "fields",
          "updated successfully"
        );
      },
      (err) => {
        this.headerService.showToast("danger", "fields", err["statusText"]);
      }
    );
    
  }
  changeData(event) {
    this.types = [];
    for (let i = 0; i < this.typeArray.length; i++) {
      if (this.typeArray[i].type === "fieldGroup") {
        this.types.push(this.typeArray[i]);
      }
    }
    if (this.Form.value.groups.length === 0) {
      this.types = this.typeArray;
    }
  }

  getFields() {
    this.fieldsService.getFields().subscribe((res) => {
      this.dropdownList = res["data"]["result"];
    });
  }

  getValidations() {
    this.fieldsService.getValidation().subscribe((res) => {
      this.validationArray = res["data"]["result"];
    });
  }
  searchThis(value) {
    this.searchArray = this.dropdownList;
    let filterArray = [];
    filterArray = this.searchArray.filter((val) =>
      val.label.toLowerCase().includes(value.toLowerCase())
    );
    this.searchArray = filterArray;
  }
  ngOnDestroy() {
    this.routeSub.unsubscribe();
  }
}
