import { Component, OnInit } from "@angular/core";
import { FieldsService } from "../../../@core/mock/fields.service";
import { Router } from "@angular/router";

@Component({
  selector: "ngx-validation-list",
  templateUrl: "./validation-list.component.html",
  styleUrls: ["./validation-list.component.scss"],
})
export class ValidationListComponent implements OnInit {
  validationArray = [];
  searchArray = [];
  constructor(private fieldService: FieldsService, private route: Router) {}

  ngOnInit(): void {
    this.fieldService.getValidation().subscribe((res) => {
      this.validationArray = res["data"]["result"];
      this.searchArray = res["data"]["result"];
    });
  }

  routeToUpdate(id) {
    this.route.navigate(["pages/layout/singleValidation/", id]);
  }
  searchThis(value) {
    let filterArray = this.validationArray;
    filterArray = this.validationArray.filter((val) =>
      val.name.toLowerCase().includes(value.toLowerCase())
    );
    this.validationArray = filterArray;
    if (filterArray.length === 0 || value === "") {
      this.validationArray = this.searchArray;
    }
  }
}
