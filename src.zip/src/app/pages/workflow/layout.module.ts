import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
  NbAccordionModule,
  NbButtonModule,
  NbCardModule,
  NbListModule,
  NbRouteTabsetModule,
  NbStepperModule,
  NbTabsetModule,
  NbUserModule,
  NbTooltipModule,
} from "@nebular/theme";

import { ThemeModule } from "../../@theme/theme.module";
import { LayoutRoutingModule } from "./layout-routing.module";
import { LayoutComponent } from "./layout.component";
import {
  Tab1Component,
  Tab2Component,
  TabsComponent,
} from "./tabs/tabs.component";
import { StepperComponent } from "./workflow/stepper.component";
import { ListComponent } from "./editWorkflow/list.component";
import { InfiniteListComponent } from "./infinite-list/infinite-list.component";
import { NewsPostComponent } from "./infinite-list/news-post/news-post.component";
import { NewsPostPlaceholderComponent } from "./infinite-list/news-post-placeholder/news-post-placeholder.component";
import { AccordionComponent } from "./accordion/accordion.component";
import { NewsService } from "./news.service";
import { MatIconModule } from "@angular/material/icon";
import { DragDropModule } from "@angular/cdk/drag-drop";
import { MatSelectModule } from "@angular/material/select";
import { NgxMatSelectSearchModule } from "ngx-mat-select-search";
import { MatAutocompleteModule } from "@angular/material/autocomplete";

import {
  NbActionsModule,
  NbCheckboxModule,
  NbDatepickerModule,
  NbIconModule,
  NbInputModule,
  NbRadioModule,
  NbSelectModule,
  NbProgressBarModule,
  NbSpinnerModule,
} from "@nebular/theme";
import { WorkflowService } from "../../@core/mock/workflow.service";
import { HeaderService } from "../../header.service";
import { FieldsComponent } from "./fields/fields.component";
import { MatOptionModule } from "@angular/material/core";
import { MatFormFieldModule } from "@angular/material/form-field";
import { FieldsService } from "../../@core/mock/fields.service";
import { FieldslistComponent } from "./fieldslist/fieldslist.component";
import { EditStepsComponent } from "./edit-steps/edit-steps.component";
import { MatInputModule } from "@angular/material/input";
import { EditFieldComponent } from "./edit-field/edit-field.component";
import { NgMultiSelectDropDownModule } from "ng-multiselect-dropdown";
import { ValidationComponent } from "./validation/validation.component";
import { MatButtonToggleModule } from "@angular/material/button-toggle";
import { ValidationListComponent } from "./validation-list/validation-list.component";
import { MatButtonModule } from "@angular/material/button";
import { SingleValidationComponent } from "./single-validation/single-validation.component";

@NgModule({
  imports: [
    FormsModule,
    ReactiveFormsModule,
    NbProgressBarModule,
    NbSpinnerModule,
    ThemeModule,
    NbTabsetModule,
    NbRouteTabsetModule,
    NbStepperModule,
    NbCardModule,
    NbButtonModule,
    NbListModule,
    NbAccordionModule,
    NbUserModule,
    LayoutRoutingModule,
    NbActionsModule,
    NbCheckboxModule,
    NbDatepickerModule,
    NbIconModule,
    NbInputModule,
    NbRadioModule,
    NbSelectModule,
    DragDropModule,
    MatIconModule,
    NbTooltipModule,
    MatSelectModule,
    MatOptionModule,
    MatFormFieldModule,
    NgxMatSelectSearchModule,
    MatAutocompleteModule,
    MatInputModule,
    NgMultiSelectDropDownModule,
    MatButtonToggleModule,
    MatButtonModule,
  ],
  declarations: [
    LayoutComponent,
    TabsComponent,
    Tab1Component,
    Tab2Component,
    StepperComponent,
    ListComponent,
    NewsPostPlaceholderComponent,
    InfiniteListComponent,
    NewsPostComponent,
    AccordionComponent,
    FieldsComponent,
    FieldslistComponent,
    EditStepsComponent,
    EditFieldComponent,
    ValidationComponent,
    ValidationListComponent,
    SingleValidationComponent,
  ],
  providers: [NewsService, WorkflowService, HeaderService, FieldsService],
})
export class LayoutModule {}
