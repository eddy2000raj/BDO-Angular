import { Component, OnInit ,ViewChild} from '@angular/core';
import { FormBuilder, FormGroup, Validators,FormArray,FormControl } from '@angular/forms';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';
import {Router} from "@angular/router"
import { WorkflowService } from '../../../@core/mock/workflow.service';
import { HeaderService } from '../../../header.service';


@Component({
  selector: 'ngx-stepper',
  templateUrl: 'stepper.component.html',
  styleUrls: ['stepper.component.scss'],
})
export class StepperComponent implements OnInit {

  Form: FormGroup;
  workspaceValue='';
  stepsValue='';
  indexOfStep:number;
  bool:boolean=false;
  boolField:boolean=false
  
  @ViewChild('item', { static: true }) accordion;

  constructor(private fb: FormBuilder,private route:Router, private workflow:WorkflowService, private headerService:HeaderService) {
  }

  ngOnInit() {
    this.Form = this.fb.group({
      workspace: ['', Validators.required],
      steps:this.fb.array([]),
    });
  }

  steps() : FormArray {
    return this.Form.get("steps") as FormArray
  }
  newStep(): FormGroup {
    return this.fb.group({
     step:'',
     fields:this.fb.array([])
    })
  }
  fieldsArray(stepIndex):FormArray{
    return  this.steps().at(stepIndex).get("fields") as FormArray
  }

  addWorkflow(){
  }
  newField():FormGroup{
    return this.fb.group({
      field:'',
      type:'',
     })
  }

  addQuantity() {
    this.steps().push(this.newStep());
  }
   
  removeQuantity(i:number) {
    this.steps().removeAt(i);
  }

  addFields(stepIndex){
    this.fieldsArray(stepIndex).push(this.newField())
  }
  showField(stepIndex:number){
    this.indexOfStep=stepIndex
    this.boolField=true
   
    
    this.bool=false
    this.stepsValue=this.Form.value.steps[stepIndex].step
    
    
  }

  removeFields(stepIndex:number,i:number) {
    this.fieldsArray(stepIndex).removeAt(i);
  }

   
  onSubmit() {
   
  }

  addWorkspace(){
    this.bool=true
    this.workspaceValue=this.Form.value.workspace;
    
  }
  viewWorkspace(){
    this.bool=false
    this.boolField=false
    
  }

  viewSteps(){
    this.bool=true;
    this.boolField=false
  }

  drop(event: CdkDragDrop<string[]>) {
    
  
      moveItemInArray(this.steps().controls, event.previousIndex, event.currentIndex);
  }


  dropField(event: CdkDragDrop<string[]> ,stepindex) {
    
      moveItemInArray(this.fieldsArray(stepindex).controls, event.previousIndex, event.currentIndex);
  }
  routeToUpdate(){
    const obj={
      name:this.Form.value.workspace,
      key:"",
   
    }
    
    
    this.workflow.postWorkflow(obj).subscribe(res=>{
     if(res['statusCode']===200){
       this.headerService.setWorkflow(res['data']['result'].name,res['data']['result'].key)
       this.headerService.showToast('success','Workflow','succesfully added');
       this.route.navigate(['pages/layout/editWorkflow',res['data']['result'].key ])
     }
    },(err)=>{
      this.headerService.showToast('danger', "Try again!", err['statusText']);
     })
  }
}
