import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-edit-steps',
  templateUrl: './edit-steps.component.html',
  styleUrls: ['./edit-steps.component.scss']
})
export class EditStepsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
