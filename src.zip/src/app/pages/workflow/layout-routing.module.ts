import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LayoutComponent } from './layout.component';
import { Tab1Component, Tab2Component, TabsComponent } from './tabs/tabs.component';
import { AccordionComponent } from './accordion/accordion.component';
import { InfiniteListComponent } from './infinite-list/infinite-list.component';
import { ListComponent } from './editWorkflow/list.component';
import { StepperComponent } from './workflow/stepper.component';
import { FieldsComponent } from './fields/fields.component';
import { FieldslistComponent } from './fieldslist/fieldslist.component';
import { EditStepsComponent } from './edit-steps/edit-steps.component';
import { EditFieldComponent } from './edit-field/edit-field.component';
import { ValidationComponent } from './validation/validation.component';
import { ValidationListComponent } from './validation-list/validation-list.component';
import { SingleValidationComponent } from './single-validation/single-validation.component';

const routes: Routes = [{
  path: '',
  component: LayoutComponent,
  children: [
    {
      path: 'workflow',
      component: StepperComponent,
    },
    {
      path: 'editStep/:key',
      component: EditStepsComponent,
    },
    {
      path: 'editWorkflow/:key',
      component: ListComponent,
    },
   {
      path: 'editField/:key',
      component: EditFieldComponent,
    }, 
    {
      path: 'fields',
      component: FieldsComponent,
    },
    {
      path: 'fieldslist',
      component: FieldslistComponent,
    },
    {
      path: 'accordion',
      component: AccordionComponent,
    },
    {
      path: 'validation',
      component: ValidationComponent,
    },
    {
      path: 'validationList',
      component: ValidationListComponent,
    },
    {
      path: 'singleValidation/:_id',
      component: SingleValidationComponent,
    },
    {
      path: 'tabs',
      component: TabsComponent,
      children: [
        {
          path: '',
          redirectTo: 'tab1',
          pathMatch: 'full',
        },
        {
          path: 'tab1',
          component: Tab1Component,
        },
        {
          path: 'tab2',
          component: Tab2Component,
        },
      ],
    },
  ],
},
{ path: '**', redirectTo: '' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LayoutRoutingModule {
}
