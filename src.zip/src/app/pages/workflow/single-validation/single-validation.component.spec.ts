import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleValidationComponent } from './single-validation.component';

describe('SingleValidationComponent', () => {
  let component: SingleValidationComponent;
  let fixture: ComponentFixture<SingleValidationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SingleValidationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
