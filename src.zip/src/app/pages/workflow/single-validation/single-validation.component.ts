import { Component, OnInit } from "@angular/core";
import { TypeService } from "../../../@core/mock/type.service";
import { FieldsService } from "../../../@core/mock/fields.service";
import { HeaderService } from "../../../header.service";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormArray,
  FormControl,
} from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { Subscription } from "rxjs";
import { StoreService } from "../../../@core/mock/store.service";
@Component({
  selector: "ngx-single-validation",
  templateUrl: "./single-validation.component.html",
  styleUrls: ["./single-validation.component.scss"],
})
export class SingleValidationComponent implements OnInit {
  Form: FormGroup;
  type = [];
  types = [];
  validationArray = [];
  status = "";
  private routeSub: Subscription;
  constructor(
    private fb: FormBuilder,
    private headerService: HeaderService,
    private fieldService: FieldsService,
    private typeService: TypeService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.getData();
    this.fieldService.getFieldTypes().subscribe((res) => {
      this.type = res["data"]["result"]["types"];

      for (let i = 0; i < this.type.length; i++) {
        if (this.type[i].type === "validation") {
          this.types.push(this.type[i]);
        }
      }
    });
    this.Form = this.fb.group({
      _id: [""],
      name: [""],
      options: this.fb.array([]),
      type: [""],
      status: [""],
    });
  }

  getData() {
    this.routeSub = this.route.params.subscribe((params) => {
      this.fieldService.getValidationById(params["_id"]).subscribe((res) => {
        this.validationArray = res["data"]["result"];
        this.status = res["data"]["result"].status.toString();
        

        this.Form.patchValue(this.validationArray);
        for (let i = 0; i < res["data"]["result"].options.length; i++) {
          this.addQuantity();
        }
      });
    });
  }

  options(): FormArray {
    return this.Form.get("options") as FormArray;
  }
  newOptions(): FormGroup {
    return this.fb.group({
      key: "",
      value: "",
    });
  }
  addQuantity() {
    this.options().push(this.newOptions());
    this.Form.patchValue(this.validationArray);
  }
  removeQuantity(stepIndex: number) {
    this.options().removeAt(stepIndex);
  }

  save() {
    this.Form.value._id = this.validationArray["_id"];
    this.fieldService.updateValidation(this.Form.value).subscribe(
      (res) => {
        
        this.headerService.showToast(
          "success",
          "validation",
          "successfully updated"
        );
      },
      (err) => {
        this.headerService.showToast(
          "danger",
          "validation",
          "unable to save !"
        );
      }
    );
  }
}
