import { Component, ViewChild, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { WorkflowService } from "../../../@core/mock/workflow.service";
import { HeaderService } from "../../../header.service";
import { workflow, stepsArray } from "../../../@core/data/workflow";
import {
  CdkDragDrop,
  moveItemInArray,
  transferArrayItem,
} from "@angular/cdk/drag-drop";

@Component({
  selector: "ngx-accordion",
  templateUrl: "accordion.component.html",
  styleUrls: ["accordion.component.scss"],
})
export class AccordionComponent implements OnInit {
  workflowArray: workflow[];
  searchArray: any = [];
  steps: [];

  users: { name: string; title: string }[] = [
    { name: "Carla Espinosa", title: "Nurse" },
    { name: "Bob Kelso", title: "Doctor of Medicine" },
    { name: "Janitor", title: "Janitor" },
    { name: "Perry Cox", title: "Doctor of Medicine" },
    { name: "Ben Sullivan", title: "Carpenter and photographer" },
  ];

  @ViewChild("item", { static: true }) accordion;

  constructor(
    private route: Router,
    private workflowService: WorkflowService,
    private headerService: HeaderService
  ) {}
  ngOnInit() {
    this.workflowService.getWorkflow().subscribe(
      (res: workflow[]) => {
        this.workflowArray = res;
        this.searchArray = res;
        
      },
      (err) => {
        this.headerService.showToast(
          "danger",
          "Workflow",
          "unable to load data"
        );
      }
    );
  }

  routeToUpdateWorkflow(id) {
    this.route.navigate(["pages/layout/editWorkflow/", id]);
  }

  routeToUpdateStep(id) {
    this.route.navigate(["pages/layout/editStep/", id]);
  }

  toggle() {
    this.accordion.toggle();
  }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(
      this.workflowArray,
      event.previousIndex,
      event.currentIndex
    );
  }

  dropStep(event: CdkDragDrop<any>, stepindex: number) {
    moveItemInArray(this.steps, event.previousIndex, event.currentIndex);
  }

  searchThis(value) {
    let filterArray = this.workflowArray;
    filterArray = this.workflowArray.filter((val) =>
      val.name.toLowerCase().includes(value.toLowerCase())
    );
    this.workflowArray = filterArray;
    if (filterArray.length === 0 || value === "") {
      this.workflowArray = this.searchArray;
    }
  }
}
