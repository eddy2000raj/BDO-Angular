import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators,FormArray,FormControl } from '@angular/forms';
import { IDropdownSettings, } from 'ng-multiselect-dropdown';
import { TypeService } from '../../../@core/mock/type.service';
import { FieldsService } from '../../../@core/mock/fields.service';
import { HeaderService } from '../../../header.service';

@Component({
  selector: 'ngx-validation',
  templateUrl: './validation.component.html',
  styleUrls: ['./validation.component.scss']
})
export class ValidationComponent implements OnInit {
Form:FormGroup
type=[];
types=[];
fieldsArray=[];
validationArray=[];
dropdownSettings:IDropdownSettings={};
  constructor(private fb:FormBuilder, private typeService:TypeService, private fieldService:FieldsService, private headerService:HeaderService) { }

  ngOnInit(): void {
    this.dropdownSettings = {
      idField: '_id',
      textField: 'label',
      enableCheckAll: false,
      noDataAvailablePlaceholderText: "There is no item availabale to show",
      allowSearchFilter: true
    };
   this.fieldService.getFieldTypes().subscribe(res=>{
     this.type=res['data']['result']['types']
     for(let i=0;i<this.type.length;i++){
       if(this.type[i].type==="validation"){
         this.types.push(this.type[i])
       }
     }
     
   })
    this.Form=this.fb.group({
      name:[''],
     options:this.fb.array([]),
      type:[''],
      status:['']
    })
  }


  options() : FormArray {
    return this.Form.get("options") as FormArray
  }
  newOptions(): FormGroup {
    return this.fb.group({
     key:'',
     value:''
    })
  }
  addQuantity() {
   this.options().push(this.newOptions());

 }
 removeQuantity(stepIndex:number){
  this.options().removeAt(stepIndex);
 }

  save(){
    if(this.Form.value.status==="true"){
      this.Form.value.status=true
    }
    else{
      this.Form.value.status=false
    }
    
    this.fieldService.postValidation(this.Form.value).subscribe(res=>{
      
      this.headerService.showToast("success","validation","added successfully")

    },err=>{
      this.headerService.showToast("danger",
      "validation",
      err["error"]["message"]
      );

    })

    
  }

}
