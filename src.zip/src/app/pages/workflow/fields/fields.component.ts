import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormArray,
  FormControl,
} from "@angular/forms";
import { FieldsService } from "../../../@core/mock/fields.service";
import { HeaderService } from "../../../header.service";
import { IDropdownSettings } from "ng-multiselect-dropdown";
@Component({
  selector: "ngx-fields",
  templateUrl: "./fields.component.html",
  styleUrls: ["./fields.component.scss"],
})
export class FieldsComponent implements OnInit {
  Form: FormGroup;
  dropdownList = [];
  fieldsArray = [];
  dropdownSettings: IDropdownSettings = {};
  dropdownSettingsValidation: IDropdownSettings = {};
  type = [];
  types = [];
  validation = [];
  operators = [];
  fieldData = [];
  newTypeArray = [];
  searchArray = [];
  check = "";
  constructor(
    private fb: FormBuilder,
    private fieldsService: FieldsService,
    private headerService: HeaderService
  ) {}

  ngOnInit(): void {
    this.getValidations();
    this.fieldsService.getFields().subscribe((res) => {
      this.fieldsArray = res["data"]["result"];
    });

    this.fieldsService.getFieldTypes().subscribe((res) => {
      this.type = res["data"]["result"]["types"];
      this.newTypeArray = res["data"]["result"]["types"];

      for (let i = 0; i < this.type.length; i++) {
        if (this.type[i].type === "field") this.types.push(this.type[i]);
      }
    });

    this.operators = [
      { name: "add" },
      { name: "subtract" },
      { name: "multiply" },
      { name: "divide" },
      { name: "equal" },
      { name: "function" },
    ];
    this.fieldData = [{ name: "constant" }, { name: "field" }];

    this.dropdownList = [
      { item_id: 1, item_text: "first name" },
      { item_id: 2, item_text: "username" },
      { item_id: 3, item_text: "last name" },
      { item_id: 4, item_text: "isAdmin" },
      { item_id: 5, item_text: "isUser" },
    ];
    this.dropdownSettings = {
      idField: "_id",
      textField: "label",
      enableCheckAll: false,
      noDataAvailablePlaceholderText: "There is no item availabale to show",
      allowSearchFilter: true,
    };
    this.dropdownSettingsValidation = {
      idField: "_id",
      textField: "name",
      enableCheckAll: false,
      noDataAvailablePlaceholderText: "There is no item availabale to show",
      allowSearchFilter: true,
    };

    this.Form = this.fb.group({
      label: [""],
      type: [""],
      options: this.fb.array([]),
      groups: [""],
      validations: [""],
      operator: [""],
      isEditable: true,
      isExportable: true,
      variables: this.fb.array([]),
    });
  }

  variables(): FormArray {
    return this.Form.get("variables") as FormArray;
  }

  newVar(): FormGroup {
    return this.fb.group({
      type: "",
      value: "",
    });
  }

  addVar() {
    this.variables().push(this.newVar());
  }
  removeVar(stepIndex: number) {
    this.variables().removeAt(stepIndex);
  }

  options(): FormArray {
    return this.Form.get("options") as FormArray;
  }
  newOptions(): FormGroup {
    return this.fb.group({
      key: "",
      value: "",
    });
  }
  addQuantity() {
    this.options().push(this.newOptions());
  }
  removeQuantity(stepIndex: number) {
    this.options().removeAt(stepIndex);
  }

  onSelect(event) {}

  save() {
    let newArray = [];
    let newArrayForField = [];
    let newArrayForValidation = [];
    let newArrayValid = [];
    newArrayForValidation = this.Form.value.validations;

    if (newArrayForValidation) {
      for (let i = 0; i < newArrayForValidation.length; i++) {
        newArrayValid.push(newArrayForValidation[i]._id);
        this.Form.value.validations = newArrayValid;
      }
    } else {
      this.Form.value.validations = [];
    }
    newArrayForField = this.Form.value.groups;
    if (newArrayForField) {
      for (let i = 0; i < newArrayForField.length; i++) {
        newArray.push(newArrayForField[i]._id);
      }

      this.Form.value.groups = newArray;
    } else {
      this.Form.value.groups = [];
    }
    const obj1 = {
      operator:
        this.Form.value.operator !== "" ? this.Form.value.operator : null,
      variables:
        this.Form.value.variables.length !== 0
          ? this.Form.value.variables
          : null,
    };

    const obj = {
      label: this.Form.value.label,
      type: this.Form.value.type,
      options: this.Form.value.options,
      groups: this.Form.value.groups,
      validations: this.Form.value.validations,
      isEditable: this.Form.value.isEditable,
      isExportable: this.Form.value.isExportable,
      expression:
        obj1.operator !== null || obj1.variables !== null ? obj1 : null,
    };

    

    this.fieldsService.postFields(obj).subscribe(
      (res) => {
        this.Form.reset();
        this.headerService.showToast("success", "fields", "added successfully");
      },
      (err) => {
        if (err["error"]["error"] !== null) {
          this.headerService.showToast(
            "danger",
            "fields",
            err["error"]["error"]
          );
        } else {
          this.headerService.showToast("danger", "fields", err["message"]);
        }
      }
    );
  }

  changeData(event) {
    this.types = [];
    for (let i = 0; i < this.type.length; i++) {
      if (this.type[i].type === "fieldGroup") {
        this.types.push(this.type[i]);
      }
    }
    if (this.Form.value.groups.length === 0) {
      this.types = this.type;
    }
  }

  getValidations() {
    this.fieldsService.getValidation().subscribe(
      (res) => {
        this.validation = res["data"]["result"];
      },
      (err) => {
          this.headerService.showToast(
            "danger",
            "validation",
            err["error"]["message"]
           
          );
          }  
    );
  }

  searchThis(value) {
    this.searchArray = this.fieldsArray;
    let filterArray = [];
    filterArray = this.searchArray.filter((val) =>
      val.label.toLowerCase().includes(value.toLowerCase())
    );
    this.searchArray = filterArray;
  }
}
