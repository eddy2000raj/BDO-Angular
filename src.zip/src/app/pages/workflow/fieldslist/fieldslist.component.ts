import { Component, OnInit } from "@angular/core";
import { FieldsService } from "../../../@core/mock/fields.service";
import { HeaderService } from "../../../header.service";
import { Router } from "@angular/router";

@Component({
  selector: "ngx-fieldslist",
  templateUrl: "./fieldslist.component.html",
  styleUrls: ["./fieldslist.component.scss"],
})
export class FieldslistComponent implements OnInit {
  fieldsArray: any = [];
  searchArray = [];
  constructor(
    private fieldsService: FieldsService,
    private headerService: HeaderService,
    private route: Router
  ) {}

  ngOnInit(): void {
    this.fieldsService.getFields().subscribe(
      (res) => {
        
        this.fieldsArray = res["data"]["result"];
        this.searchArray = this.fieldsArray;
      },
      (err) => {
        this.headerService.showToast("danger", "fields", "Unable to load data");
      }
    );
  }

  routeToUpdate(id) {
    this.route.navigate(["pages/layout/editField/", id]);
  }

  searchThis(value) {
    let filterArray = this.fieldsArray;
    filterArray = this.fieldsArray.filter((val) =>
      val.label.toLowerCase().includes(value.toLowerCase())
    );
    this.fieldsArray = filterArray;
    if (filterArray.length === 0 || value === "") {
      this.fieldsArray = this.searchArray;
    }
  }
}
