import {
  Component,
  OnInit,
  ViewChild,
  Directive,
  Output,
  EventEmitter,
  Input,
  SimpleChange,
} from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormArray,
  FormControl,
} from "@angular/forms";
import {
  CdkDragDrop,
  moveItemInArray,
  transferArrayItem,
} from "@angular/cdk/drag-drop";
import { HeaderService } from "../../../header.service";
import { Subscription } from "rxjs";
import { ActivatedRoute } from "@angular/router";
import { WorkflowService } from "../../../@core/mock/workflow.service";
import {
  workflow,
  stepsArray,
  fieldsArray,
} from "../../../@core/data/workflow";
import { FieldsService } from "../../../@core/mock/fields.service";

@Component({
  selector: "ngx-list",
  templateUrl: "list.component.html",
  styleUrls: ["list.component.scss"],
})
export class ListComponent implements OnInit {
  @ViewChild("item", { static: true }) accordion;

  Form: FormGroup;
  workflowObjectName: string;
  workflowObjectNameKey: string;
  workflowArray: any;
  stepID: string;
  fieldsData: any = [];
  searchArray: any = [];
  private routeSub: Subscription;
  bool: boolean = false;

  fieldss: fieldsArray[] = [];
  @Output() onCreate: EventEmitter<any> = new EventEmitter<any>();
  constructor(
    private fb: FormBuilder,
    private header: HeaderService,
    private route: ActivatedRoute,
    private workflowService: WorkflowService,
    private headerService: HeaderService,
    private fieldsService: FieldsService
  ) {}

  ngOnInit() {
    this.fieldsService.getFields().subscribe((res) => {
      this.fieldsData = res["data"]["result"];
      
    });
    this.header.getWorkflow().subscribe((data) => {
      this.workflowObjectName = data.name;
      this.workflowObjectNameKey = data.key;
    });

    this.Form = this.fb.group({
      workflow: ["", Validators.required],
      key: ["", Validators.required],
      steps: this.fb.array([]),
    });
    this.getData();
  }
  steps(): FormArray {
    return this.Form.get("steps") as FormArray;
  }
  newStep(): FormGroup {
    return this.fb.group({
      name: "",
      stepId: "",
      fields: this.fb.array([]),
    });
  }
  fields(stepIndex): FormArray {
    return this.steps().at(stepIndex).get("fields") as FormArray;
  }
  newField(): FormGroup {
    return this.fb.group({
      keyName: "",
      label: "",
    });
  }

  addQuantity() {
    this.steps().push(this.newStep());
    this.Form.patchValue(this.workflowArray);
  }

  removeQuantity(i: number) {
    if (!this.Form.value.steps[i].stepId) {
      this.steps().removeAt(i);
      return "";
    }
    const obj = {
      workflowKey: this.workflowObjectNameKey,
      stepId: this.workflowArray.steps[i].stepId,
    };
    
    if (window.confirm("Are you sure you want to delete?")) {
      this.workflowService.deleteSteps(obj).subscribe(
        (res) => {
          this.steps().removeAt(i);
          this.headerService.showToast(
            "success",
            "fields",
            "Successfully deleted"
          );
          this.fetchData();
        },
        (err) => {
          this.headerService.showToast("danger", "fields", err["statusText"]);
        }
      );
    } else {
    }
  }

  addFields(stepIndex) {
    this.bool = false;
    this.fields(stepIndex).push(this.newField());

    this.Form.patchValue(this.workflowArray);
  }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(
      this.steps().controls,
      event.previousIndex,
      event.currentIndex
    );
    if (this.Form.value.steps) {
      const obj = {
        workflowKey: this.workflowObjectNameKey,
        stepId: this.Form.value.steps[event.previousIndex].stepId,
        fieldId: "",
        index: event.currentIndex,
      };
      
      this.workflowService.postFieldPosition(obj).subscribe((res) => {
        this.fetchData();
      });
    }
  }

  dropField(event: CdkDragDrop<string[]>, stepindex) {
    moveItemInArray(
      this.fields(stepindex).controls,
      event.previousIndex,
      event.currentIndex
    );
    if (this.Form.value.steps[stepindex].fields) {
      const obj = {
        workflowKey: this.workflowObjectNameKey,
        stepId: this.workflowArray.steps[stepindex].stepId,
        fieldId: this.workflowArray.steps[stepindex].fields[event.previousIndex]
          ._id,
        index: event.currentIndex,
      };
    
      this.workflowService.postFieldPosition(obj).subscribe((res) => {
        this.fetchData();
      });
    }
  }

  saveData() {
    (this.Form.value.workflow = this.workflowObjectName),
      (this.Form.value.key = this.workflowObjectNameKey);
    
  }
  saveSteps(index) {
    const obj = {
      name: this.Form.value.steps[index].name,
      workflowKey: this.workflowObjectNameKey,
      stepId:
        this.Form.value.steps[index].stepId !== ""
          ? this.Form.value.steps[index].stepId
          : "",
    };
    this.workflowService.postStep(obj).subscribe(
      (res) => {
        
        this.workflowArray = res["data"]["result"];

        this.fetchData();
        this.headerService.showToast(
          "success",
          "Workflow",
          "Successfully added"
        );
      },
      (err) => {
        this.headerService.showToast(
          "danger",
          "Workflow",
          "unable to load data"
        );
      }
    );
  }

  assignFields(stepId, stepIndex, j, event) {
    

    const obj = {
      keyName: event.source.value,
      stepId: stepId,
      workflowKey: this.workflowObjectNameKey,
    };

    this.workflowService.assignFields(obj).subscribe(
      (res) => {
        
        this.headerService.showToast("success", "fields", "Successfully added");
        this.fetchData();
        this.bool = false;
      },
      (err) => {
        this.headerService.showToast("danger", "fields", "unable to save data");
      }
    );
  }

  bindData() {
    this.workflowArray = this.workflowService.getWorkFlowData();
    for (let i = 0; i < this.workflowArray.steps.length; i++) {
      this.addQuantity();
    }
  }

  getData() {
    this.routeSub = this.route.params.subscribe((params) => {
      this.workflowService.getWorkflowById(params["key"]).subscribe(
        (res: workflow) => {
          this.workflowArray = res["data"]["result"];
          
          for (let i = 0; i < this.workflowArray.steps.length; i++) {
            this.addQuantity();
            for (
              let j = 0;
              j < this.workflowArray.steps[i].fields.length;
              j++
            ) {
              this.addFields(i);
            }
          }
          this.workflowService.postWorkflowData(this.workflowArray);
       
          this.workflowObjectName = res["data"]["result"].name;
          this.workflowObjectNameKey = res["data"]["result"].key;
        },
        (err) => {
          this.headerService.showToast(
            "danger",
            "Workflow",
            "unable to load data"
          );
        }
      );
    });
  }

  fetchData() {
    this.routeSub = this.route.params.subscribe((params) => {
       
      this.workflowService.getWorkflowById(params["key"]).subscribe(
        (res: workflow) => {
          this.workflowArray = res["data"]["result"];
          
          this.workflowObjectName = res["data"]["result"].name;
          this.workflowObjectNameKey = res["data"]["result"].key;
        },
        (err) => {
          this.headerService.showToast(
            "danger",
            "Workflow",
            "unable to load data"
          );
        }
      );
    });
  }

  searchThis(value) {
    this.searchArray = this.fieldsData;
    let filterArray = [];
    filterArray = this.searchArray.filter((val) =>
      val.label.toLowerCase().includes(value.toLowerCase())
    );
    this.searchArray = filterArray;
  }

  deleteFields(stepIndex, j) {
    if (
      this.Form.value.steps[stepIndex].fields[j].keyName === "" ||
      this.Form.value.steps[stepIndex].stepId === ""
    ) {
      this.fields(stepIndex).removeAt(j);
      return "";
    }
    const obj = {
      keyName: this.Form.value.steps[stepIndex].fields[j].keyName,
      stepId: this.workflowArray.steps[stepIndex].stepId,
      workflowKey: this.workflowObjectNameKey,
    };
    if (window.confirm("Are you sure you want to delete?")) {
      this.workflowService.deleteFields(obj).subscribe(
        (res) => {
          
          this.fields(stepIndex).removeAt(j);
          this.fetchData();
          this.headerService.showToast(
            "success",
            "fields",
            "Successfully deleted"
          );
        },
        (err) => {
          this.headerService.showToast(
            "danger",
            "fields",
            "unable to save data"
          );
        }
      );
    } else {
    }
  }

  updateWorkflow() {
    
    const obj = {
      key: this.workflowArray.key,
      name:
        this.Form.value.workflow === ""
          ? this.workflowArray.name
          : this.Form.value.workflow,
    };
    this.workflowService.postWorkflow(obj).subscribe(
      (res) => {
        this.headerService.showToast(
          "success",
          "workflow",
          "Successfully updated"
        );
      },
      (err) => {
        this.headerService.showToast(
          "danger",
          "workflow",
          "unable to save data"
        );
      }
    );
  }
  ngOnDestroy() {
    this.routeSub.unsubscribe();
  }
}
