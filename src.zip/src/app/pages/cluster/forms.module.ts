import { NgModule } from "@angular/core";
import {
  NbActionsModule,
  NbButtonModule,
  NbCardModule,
  NbCheckboxModule,
  NbDatepickerModule,
  NbIconModule,
  NbInputModule,
  NbRadioModule,
  NbSelectModule,
  NbUserModule,
  NbListModule,
} from "@nebular/theme";

import { ThemeModule } from "../../@theme/theme.module";
import { FormsRoutingModule } from "./forms-routing.module";
import { FormsComponent } from "./forms.component";
import { FormInputsComponent } from "./form-inputs/form-inputs.component";
import { FormLayoutsComponent } from "./form-layouts/form-layouts.component";
import { DatepickerComponent } from "./datepicker/datepicker.component";
import { ButtonsComponent } from "./buttons/buttons.component";
import {
  FormsModule as ngFormsModule,
  ReactiveFormsModule,
} from "@angular/forms";
import { CreateClusterComponent } from "./create-cluster/create-cluster.component";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatOptionModule } from "@angular/material/core";
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { ClusterListComponent } from "./cluster-list/cluster-list.component";
import { ClusterUpdateComponent } from "./cluster-update/cluster-update.component";

import { MatTableModule } from "@angular/material/table";
import { Ng2SmartTableModule } from "ng2-smart-table";
@NgModule({
  imports: [
    ThemeModule,
    NbInputModule,
    NbCardModule,
    NbButtonModule,
    NbActionsModule,
    NbListModule,
    NbUserModule,
    NbCheckboxModule,
    NbRadioModule,
    NbDatepickerModule,
    FormsRoutingModule,
    NbSelectModule,
    NbIconModule,
    ngFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatOptionModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatTableModule,
    Ng2SmartTableModule,
  ],
  declarations: [
    FormsComponent,
    ButtonsComponent,
    FormInputsComponent,
    FormLayoutsComponent,
    DatepickerComponent,
    CreateClusterComponent,
    ClusterListComponent,
    ClusterUpdateComponent,
  ],
})
export class FormsModule {}
