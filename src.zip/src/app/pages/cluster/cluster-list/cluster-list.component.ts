import { Component, OnInit } from "@angular/core";
import { ClusterService } from "../../../@core/mock/cluster.service";

@Component({
  selector: "ngx-cluster-list",
  templateUrl: "./cluster-list.component.html",
  styleUrls: ["./cluster-list.component.scss"],
})
export class ClusterListComponent implements OnInit {
  clusterArray = [];
  searchArray = [];
  constructor(private clusterService: ClusterService) {}

  ngOnInit(): void {
    this.clusterService.getCluster().subscribe((res) => {
      this.clusterArray = res["result"];
      this.searchArray = res["result"];
    });
  }

  searchThis(value) {
    let filterArray = this.clusterArray;
    filterArray = this.clusterArray.filter((val) =>
      val.name.toLowerCase().includes(value.toLowerCase())
    );
    this.clusterArray = filterArray;
    if (filterArray.length === 0 || value === "") {
      this.clusterArray = this.searchArray;
    }
  }
}
