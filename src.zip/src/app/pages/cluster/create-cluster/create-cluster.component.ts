import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormArray,
  FormControl,
} from "@angular/forms";
import { WorkflowService } from "../../../@core/mock/workflow.service";
import { ClusterService } from "../../../@core/mock/cluster.service";
import { HeaderService } from "../../../header.service";

@Component({
  selector: "ngx-create-cluster",
  templateUrl: "./create-cluster.component.html",
  styleUrls: ["./create-cluster.component.scss"],
})
export class CreateClusterComponent implements OnInit {
  Form: FormGroup;
  newArray = [];
  workflowArray: any = [];
  constructor(
    private fb: FormBuilder,
    private workflowService: WorkflowService,
    private clusterService: ClusterService,
    private headerService: HeaderService
  ) {}

  ngOnInit(): void {
    this.getData();

    this.Form = this.fb.group({
      name: [""],
      onboardingWorkflowKey: [""],
    });
  }

  searchThis(value) {
    this.newArray = this.workflowArray;
    let filterArray = [];
    filterArray = this.newArray.filter((val) =>
      val.name.toLowerCase().includes(value.toLowerCase())
    );
    this.newArray = filterArray;
  }

  save() {
    for (let i = 0; i < this.workflowArray.length; i++) {
      if (
        this.Form.value.onboardingWorkflowKey === this.workflowArray[i].name
      ) {
        this.Form.value.onboardingWorkflowKey = this.workflowArray[i].key;
      }
    }
    this.clusterService.postCluster(this.Form.value).subscribe(
      (res) => {
        this.headerService.showToast(
          "success",
          "cluster",
          "successfully added"
        );
      },
      (err) => {
        this.headerService.showToast("danger",
         "cluster",
         err["error"]["message"]
           );
      }
    );
  }

  getData() {
    this.workflowArray = this.workflowService.getWorkFlowData();
    if (this.workflowArray.length <= 0) {
      this.workflowService.getWorkflow().subscribe((res) => {
        

        this.workflowArray = res;
      });
    }
  }
}
