import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormArray,
  FormControl,
} from "@angular/forms";
import { WorkflowService } from "../../../@core/mock/workflow.service";
import { ClusterService } from "../../../@core/mock/cluster.service";
import { HeaderService } from "../../../header.service";

@Component({
  selector: "ngx-cluster-update",
  templateUrl: "./cluster-update.component.html",
  styleUrls: ["./cluster-update.component.scss"],
})
export class ClusterUpdateComponent implements OnInit {
  Form: FormGroup;
  newArray = [];
  workflowArray: any = [];
  constructor(
    private fb: FormBuilder,
    private workflowService: WorkflowService,
    private clusterService: ClusterService,
    private headerService: HeaderService
  ) {}

  ngOnInit(): void {
    this.Form = this.fb.group({
      name: [""],
      onboardingWorkflowKey: [""],
    });
  }
}
