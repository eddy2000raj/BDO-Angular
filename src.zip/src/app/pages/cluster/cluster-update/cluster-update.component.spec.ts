import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClusterUpdateComponent } from './cluster-update.component';

describe('ClusterUpdateComponent', () => {
  let component: ClusterUpdateComponent;
  let fixture: ComponentFixture<ClusterUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClusterUpdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClusterUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
