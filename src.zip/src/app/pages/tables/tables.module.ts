import { NgModule } from "@angular/core";
import {
  NbCardModule,
  NbIconModule,
  NbInputModule,
  NbTreeGridModule,
  NbButtonModule,
  NbTooltipModule,
  NbSelectModule,
  NbOptionModule,
} from "@nebular/theme";
import { Ng2SmartTableModule } from "ng2-smart-table";

import { ThemeModule } from "../../@theme/theme.module";
import { TablesRoutingModule, routedComponents } from "./tables-routing.module";
import { FsIconComponent } from "./tree-grid/tree-grid.component";
import { UserService } from "../../@core/mock/users.service";
import { RolesComponent } from "./roles/roles.component";
import { NgxMatSelectSearchModule } from "ngx-mat-select-search";
import { ReactiveFormsModule } from "@angular/forms";
import { NgMultiSelectDropDownModule } from "ng-multiselect-dropdown";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatOptionModule } from "@angular/material/core";
import { MatInputModule } from "@angular/material/input";
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { AssignClusterComponent } from "./assign-cluster/assign-cluster.component";
import { MatButtonToggleModule } from "@angular/material/button-toggle";
import { HeaderService } from "../../header.service";
import { WorkflowService } from "../../@core/mock/workflow.service";
import { ClusterListComponent } from "./cluster-list/cluster-list.component";
import { MatTableModule } from "@angular/material/table";
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { ClusterManagerListComponent } from './cluster-manager-list/cluster-manager-list.component';

@NgModule({
  imports: [
    NbCardModule,
    NbTreeGridModule,
    NbIconModule,
    NbInputModule,
    ThemeModule,
    TablesRoutingModule,
    Ng2SmartTableModule,
    NgxMatSelectSearchModule,
    ReactiveFormsModule,
    NgMultiSelectDropDownModule,
    NbButtonModule,
    NbTooltipModule,
    NbSelectModule,
    NbOptionModule,
    MatFormFieldModule,
    MatOptionModule,
    MatInputModule,
    MatAutocompleteModule,
    MatButtonToggleModule,
    MatTableModule,
    MatProgressSpinnerModule,
  ],
  providers: [UserService, HeaderService, WorkflowService],

  declarations: [
    ...routedComponents,
    FsIconComponent,
    RolesComponent,
    AssignClusterComponent,
    ClusterListComponent,
    ClusterManagerListComponent,
  ],
})
export class TablesModule {}
