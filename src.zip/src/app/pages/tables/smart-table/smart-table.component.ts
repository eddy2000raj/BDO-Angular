import { Component, OnInit } from "@angular/core";
import { LocalDataSource } from "ng2-smart-table";

import { SmartTableData } from "../../../@core/data/smart-table";
import { UserService } from "../../../@core/mock/users.service";
import { HeaderService } from "../../../header.service";

import { ThemePalette } from "@angular/material/core";
import { ProgressSpinnerMode } from "@angular/material/progress-spinner";

@Component({
  selector: "ngx-smart-table",
  templateUrl: "./smart-table.component.html",
  styleUrls: ["./smart-table.component.scss"],
})
export class SmartTableComponent implements OnInit {
  loading: boolean = false;
  color: ThemePalette = "primary";
  mode: ProgressSpinnerMode = "determinate";
  settings = {
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmCreate: true,
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmSave: true,
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      name: {
        title: "Name",
        type: "string",
      },
      username: {
        title: "Username",
        type: "string",
      },
      email: {
        title: "E-mail",
        type: "string",
      },
      mobile: {
        title: "Mobile",
        type: "number",
      },
      age: {
        title: "age",
        type: "number",
      },
      /*       role: {
        title: 'role',
        type: 'html',
        editor: {
          type: 'list',
          config: {
            list: [
              {id: 1, title: 'agent'},
              {id: 2, title: 'admin'},
            ],
          },
        }
      } */
    },
  };

  source: LocalDataSource = new LocalDataSource();

  constructor(
    private service: SmartTableData,
    private userService: UserService,
    private headerService: HeaderService
  ) {
    const data = this.service.getData();
    /*  this.source.load(data); */
  }
  ngOnInit(): void {
    this.getData();
  }

  onEdit(event) {
    const obj = {
      email:event.newData.email,
      age:event.newData.age,
      mobile:event.newData.mobile,
      name:event.newData.name,
      active:true
    }
    console.log(obj);
    this.userService.updateAdminUsers(obj,event.newData.username).subscribe((res)=>{
      console.log(res);
      this.getData();
      this.headerService.showToast("success", "user", " updated successfully");
    },err=>{
      this.headerService.showToast("danger","user",err["error"]["message"])
    })
  }
  addRecord(event) {
    
    const obj = {
      name: event.newData.name,
      username: event.newData.username,
      email: event.newData.email,
      age: parseInt(event.newData.age),
      mobile: parseFloat(event.newData.mobile),
    };

    if (
      event.newData.name !== "" &&
      event.newData.username !== "" &&
      event.newData.email !== "" &&
      event.newData.mobile !== ""
    ) {
      this.loading = true;
    }


    this.userService.postAdminUsers(obj).subscribe(
      (res) => {
      //  this.loading=true;
          this.getData();
          this.loading=false;
        const object = {
          roleId: event.newData.role,
          userId: res["data"]["result"].userId,
        };
        
        this.headerService.showToast("success", "user", " added successfully");
    
        this.loading = false;
      },
      (err) => {
        this.loading = false;
        if(err["error"]["message"]==="Internal server error"){
          this.headerService.showToast("danger","user",err["error"]["message"])

        }
        else{
        for (let i = 0; i < err["error"]["message"].length; i++) {
          this.headerService.showToast(
            "danger",
            "user",
            err["error"]["message"][i]
          );
        }
      }
      }
    );
  }

  getData() {
    this.userService.getAdminUsers().subscribe((res) => {
      this.source.load(res["data"]["result"]);
    });
  }

  onDeleteConfirm(event): void {
    if (window.confirm("Are you sure , you want to delete?")) {
      console.log(event);
      
      const obj = {
        email:event.data.email,
        age:event.data.age,
        mobile:event.data.mobile,
        name:event.data.name,
        active:false
      }
      console.log(obj);
      this.userService.updateAdminUsers(obj,event.data.username).subscribe((res)=>{
        console.log(res);
        this.getData();
        this.headerService.showToast("success", "user", " deleted successfully");
      },err=>{
        this.headerService.showToast("danger","user",err["error"]["message"])
      })
    
    } else {
      event.confirm.reject();
    }
  }
}
