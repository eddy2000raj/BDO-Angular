import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignClusterComponent } from './assign-cluster.component';

describe('AssignClusterComponent', () => {
  let component: AssignClusterComponent;
  let fixture: ComponentFixture<AssignClusterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssignClusterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignClusterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
