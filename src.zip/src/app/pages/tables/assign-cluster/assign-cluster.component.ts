import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormArray,
  FormControl,
} from "@angular/forms";
import { ClusterService } from "../../../@core/mock/cluster.service";
import { UserService } from "../../../@core/mock/users.service";
import { HeaderService } from "../../../header.service";

@Component({
  selector: "ngx-assign-cluster",
  templateUrl: "./assign-cluster.component.html",
  styleUrls: ["./assign-cluster.component.scss"],
})
export class AssignClusterComponent implements OnInit {
  Form: FormGroup;
  newArray = [];
  clusterArray = [];
  secondArray = [];
  agentArray = [];

  constructor(
    private fb: FormBuilder,
    private clusterService: ClusterService,
    private userService: UserService,
    private headerService: HeaderService
  ) {}

  ngOnInit(): void {
    this.clusterService.getCluster().subscribe((res) => {
      this.clusterArray = res["result"];
    });
    this.userService.getAgents().subscribe((res) => {
       for(let i=0;i<res['data']['result'].length;i++){
         if("username" in res['data']['result'][i] && "name" in res['data']['result'][i] ){
           this.agentArray.push(res['data']['result'][i])
         }
       }
    });
    console.log(this.agentArray);
    
    this.Form = this.fb.group({
      agentId: [""],
      active: [""],
      clusterName: [""],
    });
  }

  searchThis(value) {
    this.newArray = this.clusterArray;
    let filterArray = [];
    filterArray = this.newArray.filter((val) =>
      val.name.toLowerCase().includes(value.toLowerCase())
    );
    this.newArray = filterArray;
  }

  searchAgent(value) {
    this.secondArray = this.agentArray;  
    let filterArray = [];
    filterArray = this.secondArray.filter((val) =>
    val.username.toLowerCase().includes(value.toLowerCase())
    );
    this.secondArray = filterArray;
  }
  save() {
    if (this.Form.value.active === "true") {
      this.Form.value.active = true;
    } else {
      this.Form.value.active = false;
    }

    if (this.Form.value.agentId) {
      for (let i = 0; i < this.agentArray.length; i++) {
        if (this.agentArray[i].name === this.Form.value.agentId) {
          this.Form.value.agentId = this.agentArray[i].agentId;
        }
      }
    }
    

    this.userService.assignClusterToAgent(this.Form.value).subscribe(
      (res) => {
        this.Form.reset();
        this.headerService.showToast(
          "success",
          "cluster",
          "Added successfully"
        );
      },
      (err) => {
        this.headerService.showToast(
          "danger",
          "user",
          err["error"]["message"],
          );
      }
    );
  }
}
