import { Component, OnInit } from "@angular/core";
import { SmartTableData } from "../../../@core/data/smart-table";
import { LocalDataSource } from "ng2-smart-table";
import { UserService } from "../../../@core/mock/users.service";
import { HeaderService } from "../../../header.service";
@Component({
  selector: "ngx-cluster-list",
  templateUrl: "./cluster-list.component.html",
  styleUrls: ["./cluster-list.component.scss"],
})
export class ClusterListComponent implements OnInit {
  settings = {
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmSave: true,
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    actions: {
      add: false,
      edit: false,
      delete:false
    },
    columns: {
      name: {
        title: "Name",
        type: "string",
      },
      username: {
        title: "Username",
        type: "string",
      },
      clusterName: {
        title: "Cluster Name",
        type: "string",
      },
      active: {
        title: "active ",
        type: "boolean",
      },
    },
  };
  source: LocalDataSource = new LocalDataSource();
  constructor(
    private service: SmartTableData,
    private userService: UserService,
    private headerService: HeaderService
  ) {
    /*     const data = this.service.getData();
    this.source.load(data); */
  }

  ngOnInit(): void {
    this.getData();
  }

  onEdit(event) {}
  onDeleteConfirm(event) {}

  getData() {
    this.userService.getAgents().subscribe((res) => {
      
      this.source.load(res["data"]["result"]);
    });
  }
}
