import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormArray,
  FormControl,
} from "@angular/forms";
import { IDropdownSettings } from "ng-multiselect-dropdown";
import { ClusterService } from "../../../@core/mock/cluster.service";
import { UserService } from "../../../@core/mock/users.service";
import { HeaderService } from "../../../header.service";
@Component({
  selector: "ngx-roles",
  templateUrl: "./roles.component.html",
  styleUrls: ["./roles.component.scss"],
})
export class RolesComponent implements OnInit {
  Form: FormGroup;
  users = [];
  newArray = [];
  newArrayForCluster=[];
  clusterArray=[]
  dropdownSettings: IDropdownSettings = {};
  dropdownSettings1: IDropdownSettings = {};
  dropdownData = [
    { item_id: 1, item_text: "agent" },
    { item_id: 2, item_text: "admin" },
  ];
  roles: any = [];
  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private headerService: HeaderService,
    private clusterService:ClusterService
  ) {}

  ngOnInit(): void {
    this.userService.getAdminUsers().subscribe((res) => {
      this.users = res["data"]["result"];    
    });
    this.userService.getAgentRoles().subscribe((res) => {
      for(let i=0;i<res["data"]["result"].length;i++){  
        if(res['data']['result'][i].roleId!=="panelAccess"){
          this.roles.push(res['data']['result'][i])
        }
      }
    });
    this.clusterService.getCluster().subscribe((res) => {
    
      this.clusterArray = res["result"];
    });
   

    this.dropdownSettings = {
      idField: "id",
      textField: "name",
      allowSearchFilter: true,
      enableCheckAll: true,
      selectAllText:'Select All',
      unSelectAllText:'UnSelect All',
      noDataAvailablePlaceholderText: "There is no item available to show",
    };
    this.dropdownSettings1 = {
      idField: "userId",
      textField: "username",
      enableCheckAll: false,
      noDataAvailablePlaceholderText: "There is no item available to show",
      allowSearchFilter: true,
    };
    this.Form = this.fb.group({
      roleId: [""],
      userId: [""],
      clusterId:[''],
      clusterIdAgent:['']
    });
  }

  searchThis(value) {
    this.newArray = this.users;
    let filterArray = [];
    filterArray = this.newArray.filter((val) =>
      val.username.toLowerCase().includes(value.toLowerCase())
    );
    this.newArray = filterArray;
  }
  searchCluster(value) {
    this.newArrayForCluster= this.clusterArray;
    let filterArray = [];
    filterArray = this.newArrayForCluster.filter((val) =>
      val.name.toLowerCase().includes(value.toLowerCase())
    );
    this.newArrayForCluster = filterArray;
  }

  save() {
    let clusterFormArray=[]
    let clusterFormArrayAgent=[]
    if(this.Form.value.clusterIdAgent){
      for(let i=0;i<this.clusterArray.length;i++){
        if(this.Form.value.clusterIdAgent===this.clusterArray[i].name){
          clusterFormArrayAgent.push(this.clusterArray[i].id);
      
        }
      }
    }
    else if(this.Form.value.clusterId && this.Form.value.clusterId!==null ){
    for(let i=0;i<this.Form.value.clusterId.length;i++){
    for(let j=0;j<this.clusterArray.length;j++){
      if(this.Form.value.clusterId[i].name===this.clusterArray[j].name){
        clusterFormArray.push(this.clusterArray[j].id)
      }
    }
    }
  }

    for (let i = 0; i < this.users.length; i++) {
      if (this.Form.value.userId === this.users[i].username) {
        this.Form.value.userId = this.users[i].userId;
      }
    }

    const obj={
      userId:this.Form.value.userId,
      roleId:this.Form.value.roleId,
      clusterIds:clusterFormArray.length!==0?clusterFormArray:clusterFormArrayAgent
    }
    this.userService.assignRoles(obj).subscribe(
      (res) => {
        this.headerService.showToast("success", "user", " added successfully");
        this.Form.reset();
      },
      (err) => {
        this.headerService.showToast("danger", "user", err["error"]["message"]);
      }
    ); 
    this.Form.reset()
  }
}
