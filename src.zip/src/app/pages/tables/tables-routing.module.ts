import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { TablesComponent } from "./tables.component";
import { SmartTableComponent } from "./smart-table/smart-table.component";
import { TreeGridComponent } from "./tree-grid/tree-grid.component";
import { RolesComponent } from "./roles/roles.component";
import { AssignClusterComponent } from "./assign-cluster/assign-cluster.component";
import { ClusterListComponent } from "./cluster-list/cluster-list.component";
import { ClusterManagerListComponent } from "./cluster-manager-list/cluster-manager-list.component";

const routes: Routes = [
  {
    path: "",
    component: TablesComponent,
    children: [
      {
        path: "user-table",
        component: SmartTableComponent,
      },
      {
        path: "tree-grid",
        component: TreeGridComponent,
      },
      {
        path: "roles",
        component: RolesComponent,
      },
      {
        path: "assign",
        component: AssignClusterComponent,
      },
      {
        path: "agents",
        component: ClusterListComponent,
      },
      {
        path: "cluster-Manager",
        component: ClusterManagerListComponent,
      },
    ],
  },
  { path: '**', redirectTo: '' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TablesRoutingModule {}

export const routedComponents = [
  TablesComponent,
  SmartTableComponent,
  TreeGridComponent,
];
