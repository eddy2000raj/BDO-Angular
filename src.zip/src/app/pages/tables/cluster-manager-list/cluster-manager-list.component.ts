import { Component, OnInit } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { ProgressSpinnerMode } from '@angular/material/progress-spinner';
import { LocalDataSource } from 'ng2-smart-table';
import { SmartTableData } from '../../../@core/data/smart-table';
import { UserService } from '../../../@core/mock/users.service';
import { HeaderService } from '../../../header.service';

@Component({
  selector: 'ngx-cluster-manager-list',
  templateUrl: './cluster-manager-list.component.html',
  styleUrls: ['./cluster-manager-list.component.scss']
})
export class ClusterManagerListComponent implements OnInit {
  loading: boolean = false;
  color: ThemePalette = "primary";
  mode: ProgressSpinnerMode = "determinate";
  settings = {
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmCreate: true,
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmSave: true,
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    actions: {
      add: false,
      edit: false,
      delete:false
    },
    columns: {
      name: {
        title: "Name",
        type: "string",
      },
      cluster: {
        title: "clusters",
        type: "string",
      },
      active: {
        title: "active",
        type: "boolean",
      },
      /*       role: {
        title: 'role',
        type: 'html',
        editor: {
          type: 'list',
          config: {
            list: [
              {id: 1, title: 'agent'},
              {id: 2, title: 'admin'},
            ],
          },
        }
      } */
    },
  };

  source: LocalDataSource = new LocalDataSource();

  constructor(
    private service: SmartTableData,
    private userService: UserService,
    private headerService: HeaderService
  ) {
    const data = this.service.getData();
    /*  this.source.load(data); */
  }
  ngOnInit(): void {
    this.getData();
  }

  onEdit(event) {}

  addRecord(event) {
    
    const obj = {
      name: event.newData.name,
      username: event.newData.username,
      email: event.newData.email,
      age: parseInt(event.newData.age),
      mobile: parseFloat(event.newData.mobile),
    };

    if (
      event.newData.name !== "" &&
      event.newData.username !== "" &&
      event.newData.email !== "" &&
      event.newData.mobile !== ""
    ) {
      this.loading = true;
    }


    this.userService.postAdminUsers(obj).subscribe(
      (res) => {
      //  this.loading=true;
          this.getData();
          this.loading=false;
        const object = {
          roleId: event.newData.role,
          userId: res["data"]["result"].userId,
        };
        
        this.headerService.showToast("success", "user", " added successfully");
    
        this.loading = false;
      },
      (err) => {
        this.loading = false;
        if(err["error"]["message"]==="Internal server error"){
          this.headerService.showToast("danger","user",err["error"]["message"])

        }
        else{
        for (let i = 0; i < err["error"]["message"].length; i++) {
          this.headerService.showToast(
            "danger",
            "user",
            err["error"]["message"][i]
          );
        }
      }
      }
    );
  }

  getData() {
    let newArray=[]
    let obj={};
    this.userService.getClusterManager().subscribe((res) => {
     // this.source.load(res["data"]["result"]);
     console.log(res);
    for(let i=0;i<res['result'].length ;i++){

        
       obj={
        name:res['result'][i].user?.name,
        cluster:res['result'][i].clusters?res['result'][i].clusters.map(function(e){ return e.name;}).join(','):'',
        active:res['result'][i].active,
      }
      
      newArray.push(obj)
    }
    console.log(newArray);
    
    this.source.load(newArray)
    });
  }

  onDeleteConfirm(event): void {
    if (window.confirm("Are you sure you want to delete?")) {
      event.confirm.resolve();
      
    } else {
      event.confirm.reject();
    }
  }


}
