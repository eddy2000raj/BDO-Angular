import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClusterManagerListComponent } from './cluster-manager-list.component';

describe('ClusterManagerListComponent', () => {
  let component: ClusterManagerListComponent;
  let fixture: ComponentFixture<ClusterManagerListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClusterManagerListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClusterManagerListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
