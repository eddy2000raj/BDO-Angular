import { Component } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";
import { ICellRendererParams } from "ag-grid-community";
import { Router } from "@angular/router";

@Component({
  selector: "ngx-details",
  templateUrl: "./details.component.html",
  styleUrls: ["./details.component.scss"],
})
export class DetailsComponent implements ICellRendererAngularComp {
  constructor(private route: Router) {}
  response;
  agInit(params: ICellRendererParams) {
    this.response = params;
  }
  refresh(params: any): boolean {
    return true;
  }
  details() {
    this.route.navigate([
      "pages/store/storeDetails/",
      this.response.data.storeId,
    ]);
  }
}
