import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Subscription } from "rxjs";
import { StoreService } from "../../../@core/mock/store.service";
import { HeaderService } from "../../../header.service";
import { saveAs } from "file-saver";

@Component({
  selector: "ngx-single-store",
  templateUrl: "./single-store.component.html",
  styleUrls: ["./single-store.component.scss"],
})
export class SingleStoreComponent implements OnInit {
  private routeSub: Subscription;
  private routeSub1: Subscription;
  storeArray = [];
  meetingArray = [];
  newArray = [];
  textValue = "string";
  bool: boolean = true;
  constructor(
    private route: ActivatedRoute,
    private storeService: StoreService,
    private headerService: HeaderService
  ) {}

  ngOnInit(): void {
    this.getData();
  }

  getData() {
    this.routeSub = this.route.params.subscribe((params) => {
      this.storeService.getStoreById(params["storeId"]).subscribe(
        (res) => {
          this.storeArray = res["data"]["result"]["storeInfo"];
        },
        (err) => {
          this.headerService.showToast(
            "danger",
            "store",
            "Failed to load data"
          );
        }
      );
    });

    this.routeSub1 = this.route.params.subscribe((params) => {
      this.storeService.getMeetingById(params["storeId"]).subscribe(
        (res) => {
          

          this.meetingArray = res["data"]["result"];
        },
        (err) => {
          this.headerService.showToast(
            "danger",
            "store",
            "Failed to load meeting data"
          );
        }
      );
    });
  }

  getKeys(obj) {
    return Object.keys(obj);
  }
  objectKeys(obj) {
    return Object.values(obj);
  }
  getValue(obj) {
    let value: any;

    // this.bool = false;

    value = Object.keys(obj).map((key) => obj[key].type);
    let inputVals = Object.keys(obj).map((key) => obj[key].inputValue);

    if (value[0] === "modal" || value[0] === "collapse") {
      let newArray = [];
      this.bool = false;
      this.textValue = "modal";
      let data = Object.keys(obj).map((key) => obj[key].inputValue);
      newArray = this.newData(data);
      return newArray.join("\n");
    } else if (value[0] === "image") {
      this.bool = false;
      this.textValue = "image";
      return Object.keys(obj).map((key) => obj[key].inputValue);
    } else if (value[0] === "signature") {
      this.bool = false;
      this.textValue = "image";

      return Object.keys(obj).map((key) => obj[key].inputValue);
    } else if (value[0] === "downloadBtn") {
      this.textValue = "download";
      return Object.keys(obj).map((key) => obj[key].inputValue);
    } else if (value[0] === "location") {
      this.textValue = "location";
      this.bool = false;
      return Object.keys(obj).map((key) =>
        obj[key].inputValue.replace(/[^\d.,-]/g, "")
      );
    } else if (value[0] === "htmlView") {
      return "";
    } else {
      this.textValue = "string";
      this.bool = true;
      return Object.keys(obj).map((key) => obj[key].inputValue);
    }
  }
  getDataValue(obj) {
    // console.log(obj);

    return Object.keys(obj).map((key) => obj[key].inputValue);
  }

  convertToString(str) {
    if (str === "") {
      return null;
    }
    if (typeof str == "object" && !(str instanceof Array)) {
      let returnStr = "";
      for (const key in str) {
        

        if (Object.prototype.hasOwnProperty.call(str, key)) {
          returnStr += Boolean(returnStr) ? " , " : "";
          returnStr += str[key];
        }
      }
      return returnStr;
    } else {
      return str.toString();
    }
  }
  newData(data) {
    let newArray = [];
    for (let i = 0; i < data[0].length; i++) {
      newArray.push(
        " " +
          Object.keys(data[0][i])[0] +
          " - " +
          Object.keys(data[0][i]).map((key) => data[0][i][key].inputValue)
      );
    }
    return newArray;
  }
  saveFile(value) {
    if (value[0][0] !== " ") {
      saveAs(value[0]);
    } else {
      alert("No file to download");
    }
  }
  ngOnDestroy() {
    this.routeSub.unsubscribe();
    this.routeSub1.unsubscribe();
  }
}
