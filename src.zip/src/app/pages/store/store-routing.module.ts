import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { StoreComponent } from "./store.component";
import { StoreListComponent } from "./store-list/store-list.component";
import { SingleStoreComponent } from "./single-store/single-store.component";
import { StoreTableComponent } from "./store-table/store-table.component";
import { StoreDetailsComponent } from "./store-details/store-details.component";
import { StoreInformationComponent } from "./store-information/store-information.component";

const routes: Routes = [
  {
    path: "",
    component: StoreComponent,
    children: [
      {
        path: "storeList",
        component: StoreListComponent,
      },
      {
        path: "singleStore/:storeId",
        component: SingleStoreComponent,
      },
      {
        path: "storeTable",
        component: StoreTableComponent,
      },
      {
        path: "storeDetails/:storeId",
        component: StoreDetailsComponent,
      },
      {
        path: "storeInfo",
        component: StoreInformationComponent,
      },
    ],
  },
  { path: '**', redirectTo: '' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StoreRoutingModule {}
