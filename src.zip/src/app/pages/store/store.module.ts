import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { StoreRoutingModule } from "./store-routing.module";
import { StoreListComponent } from "./store-list/store-list.component";
import { StoreComponent } from "./store.component";
import { NbTabsetModule, } from "@nebular/theme";


import {
  NbActionsModule,
  NbButtonModule,
  NbCardModule,
  NbCheckboxModule,
  NbDatepickerModule,
  NbIconModule,
  NbInputModule,
  NbRadioModule,
  NbSelectModule,
  NbUserModule,
  NbListModule,
  NbAccordionModule,
  NbRouteTabsetModule,
  NbStepperModule,
  NbTooltipModule,
  NbSpinnerModule,
} from "@nebular/theme";
import { SingleStoreComponent } from "./single-store/single-store.component";
import { RouterModule } from "@angular/router";
import { Ng2SmartTableModule } from "ng2-smart-table";
import { MatTableModule } from "@angular/material/table";
import { StoreTableComponent } from "./store-table/store-table.component";
import { MatPaginatorModule } from "@angular/material/paginator";
import { MatSortModule } from "@angular/material/sort";
import { StoreDetailsComponent } from "./store-details/store-details.component";
import { StoreInformationComponent } from "./store-information/store-information.component";
import { ReactiveFormsModule } from "@angular/forms";
import { AgGridModule } from "ag-grid-angular";
import { DetailsComponent } from "./details/details.component";
import { ThemeModule } from "../../@theme/theme.module";


@NgModule({
  declarations: [
    StoreListComponent,
    StoreComponent,
    SingleStoreComponent,
    StoreTableComponent,
    StoreDetailsComponent,
    StoreInformationComponent,
    DetailsComponent,
  ],
  imports: [
    CommonModule,
    ThemeModule,
    NbTabsetModule,
    NbRouteTabsetModule,
    NbStepperModule,
    StoreRoutingModule,
    NbActionsModule,
    RouterModule,
    NbButtonModule,
    NbCardModule,
    NbCheckboxModule,
    NbDatepickerModule,
    NbIconModule,
    NbInputModule,
    NbRadioModule,
    NbSelectModule,
    NbUserModule,
    NbListModule,
    NbAccordionModule,
    Ng2SmartTableModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    NbTooltipModule,
    ReactiveFormsModule,
    AgGridModule.withComponents([StoreInformationComponent]),
    NbSpinnerModule,

  ],
  providers: [StoreModule],
  exports: [StoreRoutingModule],
})
export class StoreModule {}
