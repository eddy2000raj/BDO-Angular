import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { StoreService } from "../../../@core/mock/store.service";
import * as XLSX from "xlsx";
import { HeaderService } from "../../../header.service";


export interface RowElement {
  key: string;
  value: string;
}

@Component({
  selector: "ngx-store-table",
  templateUrl: "./store-table.component.html",
  styleUrls: ["./store-table.component.scss"],
})
export class StoreTableComponent implements OnInit {
  tableData = [];
  loadingMediumGroup = false;
  @ViewChild("TABLE") table: ElementRef;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  yourColumns: string[] = [];

  dataSource: MatTableDataSource<any[]>;

  constructor(
    private storeService: StoreService,
    private headerService: HeaderService
  ) {
    this.getData();
  }

  ngOnInit(): void {}

  getData() {
    this.storeService.getStoreTable().subscribe(
      (res) => {
        this.tableData = res["data"]["result"];
        this.dataSource = new MatTableDataSource(this.tableData);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        for (let i = 0; i < this.tableData.length; i++) {
          let row = this.tableData[i];
          for (let key of Object.keys(row)) {
            this.yourColumns.push(key);
          }
          break; //one row is enough to be used as a reference assuming the dataset is uniform
        }
      },
      (err) => {
        this.headerService.showToast(
          "danger",
          "Store Table",
          "Failed to load the data"
        );
      }
    );
  }

  downloadExcel() {
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.tableData);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "store data");
    XLSX.writeFile(wb, "storedata.xlsx");
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  exportAsExcel() {
    this.loadingMediumGroup =true;
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(
      this.table.nativeElement
    ); //converts a DOM TABLE element to a worksheet
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");

    /* save to file */
    XLSX.writeFile(wb, "SheetJS.xlsx");
    this.loadingMediumGroup = false;

  }
}
