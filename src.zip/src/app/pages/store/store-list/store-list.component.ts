import { Component, OnInit } from "@angular/core";
import { StoreService } from "../../../@core/mock/store.service";
import { Router } from "@angular/router";
import { HeaderService } from "../../../header.service";

@Component({
  selector: "ngx-store-list",
  templateUrl: "./store-list.component.html",
  styleUrls: ["./store-list.component.scss"],
})
export class StoreListComponent implements OnInit {
  storeArray = [];
  filterArray = [];
  searchArray = [];
  constructor(
    private storeService: StoreService,
    private route: Router,
    private headerService: HeaderService
  ) {}

  ngOnInit(): void {
    this.storeService.getStores().subscribe(
      (res) => {
        this.storeArray = res["data"]["result"];
        this.searchArray = res["data"]["result"];
      },
      (err) => {
        this.headerService.showToast("danger", "stores", "Failed to load data");
      }
    );
  }

  routeToUpdate(id) {
    this.route.navigate(["pages/store/singleStore/", id]);
  }

  searchThis(value) {
    let filterArray = this.storeArray;
    filterArray = this.storeArray.filter((val) =>
      val.store_name.toLowerCase().includes(value.toLowerCase())
    );
    this.storeArray = filterArray;
    if (filterArray.length === 0 || value === "") {
      this.storeArray = this.searchArray;
    }
  }
}
