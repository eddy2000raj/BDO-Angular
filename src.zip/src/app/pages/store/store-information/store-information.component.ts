import {
  Component,
  OnInit,
  AfterViewInit,
  ViewChild,
  ElementRef,
} from "@angular/core";
import { AgGridAngular } from "ag-grid-angular";
import { GridOptions, IGetRowsParams } from "ag-grid-community";
import { StoreService } from "../../../@core/mock/store.service";
import { DetailsComponent } from "../details/details.component";
import { HeaderService } from "../../../header.service";
import * as XLSX from "xlsx";
import { NbButton } from "@nebular/theme";

@Component({
  selector: "ngx-store-information",
  templateUrl: "./store-information.component.html",
  styleUrls: ["./store-information.component.scss"],
})
export class StoreInformationComponent implements OnInit {
  loadingMediumGroup = false;
  columnDefs;
  @ViewChild("agGrid") agGrid: AgGridAngular;
  rowData: any;
  AgLoad: boolean;
  gridApi: any;
  gridOptions;
  totalPages: number;
  value: any;
  newParams;
  public frameworkComponents;
  gridColumnApi: any;
  totalRecords: number;
  cacheOverflowSize;
  maxConcurrentDatasourceRequests;
  infiniteInitialRowCount;
  tableData = [];
  pages = [1, 2, 5, 10, 50, 100, 500, 1000];
  constructor(
    private storeService: StoreService,
    private headerService: HeaderService
  ) {
    //  this.getData();
    this.gridOptions = <GridOptions>{};
    this.columnDefs = [
      {
        headerName: "Store Name",
        field: "name",
        sortable: true,
        filter: true,
        width: 100,
      },
      {
        headerName: "City",
        field: "city",
        sortable: true,
        filter: true,
        width: 100,
        resizable: true,
      },
      {
        headerName: "Store Size",
        field: "size",
        sortable: true,
        filter: true,
        width: 100,
        resizable: true,
      },
      {
        headerName: "Status",
        field: "status",
        sortable: true,
        filter: true,
        resizable: true,
        width: 100,
      },
      {
        headerName: "Created Timestamp",
        field: "createdAt",
        sortable: true,
        filter: true,
        resizable: true,
        width: 100,
      },
      {
        headerName: "Agent Name",
        field: "agentName",
        sortable: true,
        filter: true,
        resizable: true,
        width: 120,
      },
      {
        headerName: "District",
        field: "district",
        sortable: true,
        filter: true,
        resizable: true,
        width: 100,
      },
      {
        headerName: "Meeting",
        field: "upcomingMeetingDate",
        sortable: true,
        filter: true,
        resizable: true,
        width: 100,
      },
      {
        headerName: "Details",
        fields: "",
        cellRenderer: "DetailsComponent",
        width: 120,
      },
    ];
    this.cacheOverflowSize = 2;
    this.maxConcurrentDatasourceRequests = 2;
    this.infiniteInitialRowCount = 2;
    // this.GetGiftVoucherList();
    this.gridOptions = {
      enableFilter: true,
      enableSorting: true,
      pagination: true,
      cacheBlockSize: 20,
      paginationPageSize: 20,
      rowModelType: "infinite",
      defaultExportParams: {
        allColumns: true,
      },
    };
    this.frameworkComponents = {
      DetailsComponent: DetailsComponent,
    };
  }

  ngOnInit() {}
  GetAgColumns() {}
  /*  getData() {
    this.storeService.getStaticTable(1).subscribe(
      (res) => {
        
        this.tableData = res["data"]["result"];
        this.totalPages = res["data"]["meta"]["total_pages"];
        
        this.gridOptions = {
          columnDefs: this.columnDefs,
          enableFilter: true,
          enableSorting: true,
          pagination: true,
          cacheBlockSize: this.totalPages,
          paginationPageSize: res["data"]["meta"]["limit"],
          defaultExportParams: {
            allColumns: true,
          },
        };
      },
      (err) => {
        this.headerService.showToast("danger", "store", "Failed to load data");
      }
    );
  } */
  GetGiftVoucherList() {
    this.AgLoad = true;
  }
  onPaginationChanged(data) {}
  BindData(params) {
    let count;
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    let datasource = {
      getRows: (params: IGetRowsParams) => {
        
        this.newParams = params;
        count = (params.endRow / 20)
        if (count == 0) {
          count = 1;
        }
        this.gridApi.showLoadingOverlay();
        this.storeService.getStaticTable(count, params).subscribe((res) => {
          
          this.gridApi.showLoadingOverlay();
          //    this.gridOptions.suppressNoRowsOverlay = false;
          setTimeout(() => {
            params.successCallback(
              res["data"]["result"],
              res["data"]["meta"]["total_records"]
            );
            this.gridApi.hideOverlay();
          }, 0);
          count=0;
        });
      },
    };

    this.gridApi.setDatasource(datasource);
  }

  exportAsExcel() {
    this.loadingMediumGroup = true;

    

    // this.gridApi.setDatasource(datasource);
    this.exportWithXLSX(this.newParams);
    //   this.agGrid.api.exportDataAsCsv(this.getParams());
  }

  exportWithXLSX(newParams) {
    let datasource;
    let count = 1;
    this.storeService
      .getStaticTableForExport(count, newParams)
      .subscribe((res) => {
        
        datasource = res["data"]["result"];

        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(datasource);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "store data");
        XLSX.writeFile(wb, "storedata.csv");
        this.loadingMediumGroup = false;
      });
  }
  getParams() {
    return { allColumns: true };
  }
}
