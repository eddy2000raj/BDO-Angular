import { Injectable } from '@angular/core';
import {
  NbComponentStatus,
  NbGlobalLogicalPosition,
  NbGlobalPhysicalPosition,
  NbGlobalPosition,
  NbToastrService,
  NbToastrConfig,
} from '@nebular/theme';
import {BehaviorSubject} from "rxjs"


@Injectable({
  providedIn: 'root'
})
export class HeaderService {
destroyByClick = true;
config: NbToastrConfig;
duration = 2000;
hasIcon = true;
position: NbGlobalPosition = NbGlobalPhysicalPosition.TOP_RIGHT;
preventDuplicates = false;
status: NbComponentStatus = 'primary';
workflowName:string;
workflowKey:string;
obj={
  Name:'',
  Key:''
}


public content = new BehaviorSubject<any>(this.obj);    
public share = this.content.asObservable();
  constructor(private toastrService: NbToastrService) { }

  setWorkflow(workflowName, workflowKey){
    
    this.obj={
      Name:workflowName,
      Key:workflowKey
    }
    this.content.next(this.obj);
    
  }
 getWorkflow(){
    return this.share;
  }

  showToast(type: NbComponentStatus, title: string, body: string) {
    const config = {
      status: type,
      destroyByClick: this.destroyByClick,
      duration: this.duration,
      hasIcon: this.hasIcon,
      position: this.position,
      preventDuplicates: this.preventDuplicates,
    };
    const titleContent = title ? `. ${title}` : '';
    this.toastrService.show(
      body,
      `1k-admin ${titleContent}`,
      config);
  }
}
