import { Injectable } from '@angular/core';
import { Observable , of, from} from 'rxjs';
import {environment} from "../../src/environments/environment"
import {HttpClient} from "@angular/common/http"
import { catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  loginPath:string=environment.link +"/auth/login"
  private redirectUrl: string | undefined = '/pages/layout/workflow';
  private loginUrl: string = '/';
  
  public isloggedIn: boolean ;
  public loggedInUser: any;
  constructor(private http:HttpClient) { }
  isLoggedInUser() {
    return localStorage.getItem('ACCESS_TOKEN') !== null;
  }

  getRedirectUrl(): string | undefined {
		return this.redirectUrl;
	}
	setRedirectUrl(url: string | undefined): void {
		this.redirectUrl = url;
	}
	getLoginUrl(): string {
		return this.loginUrl;
	}
   logout() {
     this.isloggedIn = false;
     localStorage.clear();
     window.location.reload();
 
  }

  LoginPost(data){
    return this.http.post(this.loginPath,data)

  }
}
