export interface storeInformation {
  storeId: number;
  name?: string;
  district: string;
  createdAt: string;
  agentName: string;
  status: string;
  size: number;
  city: string;
}
