Application-wise data providers in 1k
