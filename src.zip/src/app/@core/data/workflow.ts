export interface workflow{
    name:string,
    key:string,
    position:number,
    steps:stepsArray
}

export interface stepsArray{
    name:string,
   
}

export interface fieldsArray{
    field:string,
}


