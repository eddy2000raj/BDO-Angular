export enum permissions {
    READ = "read",
    WRITE = "write",
    CAN_CREATE_WORKFLOW = "can-create-workflow",
    CAN_UPDATE_WORKFLOW = "can-update-workflow",
    CAN_VIEW_WORKFLOW = "can-view-workflow",
    CAN_CREATE_STEP = "can-create-step",
    CAN_UPDATE_STEP = "can-update-step",
    CAN_CREATE_USER = "can-create-user",
    CAN_UPDATE_USER = "can-update-user",
    CAN_VIEW_USER = "can-view-user",
    CAN_ASSIGN_ROLE = "can-assign-role",
    CAN_UPDATE_FIELD = "can-update-field",
    CAN_CREATE_FIELD = "can-create-field",
    CAN_VIEW_FIELD = "can-view-field",
    CAN_DELETE_FIELD = "can-delete-field",
    CAN_CREATE_VALIDATION = "can-create-validation",
    CAN_VIEW_VALIDATION = "can-view-validation",
    CAN_CREATE_CLUSTER = "can-create-cluster",
    CAN_VIEW_CLUSTER = "can-view-cluster",
    CAN_VIEW_ROLES = "can-view-roles",
  }
  
  