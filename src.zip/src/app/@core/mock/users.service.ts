import { of as observableOf,  Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { Contacts, RecentUsers, UserData } from '../data/users';
import {HttpClient,HttpHeaders } from '@angular/common/http'
import {environment} from "../../../../src/environments/environment"
import { HeaderService } from '../../header.service';


@Injectable()
export class UserService  {

  httpoptions={
    headers : new HttpHeaders({
      'Content-Type': 'application/json',
      'responseType': 'json',
      Authorization:'Bearer ' +localStorage.getItem('ACCESS_TOKEN'),
  })
    };
    user:string=environment.link+"/users";
    agent:string=environment.link+"/agent";
    roles:string=environment.link+"/roles";
    clusterManager:string=environment.link+"/clusterManager";
    constructor( private http:HttpClient){

    }
  
  private time: Date = new Date;

  private users = {
    nick: { name: 'Aryan Aman', picture: 'assets/images/nick.png' , password: '123' },
    eva: { name: 'Eva Moor', picture: 'assets/images/eva.png' , password: '123' },
    jack: { name: 'Jack Williams', picture: 'assets/images/jack.png', password: '123'  },
    lee: { name: 'Lee Wong', picture: 'assets/images/lee.png', password: '123'  },
    alan: { name: 'Alan Thompson', picture: 'assets/images/alan.png' , password: '123' },
    kate: { name: 'Kate Martinez', picture: 'assets/images/kate.png' , password: '123' },
  };
  private types = {
    mobile: 'mobile',
    home: 'home',
    work: 'work',
  };
  private contacts: Contacts[] = [
    { user: this.users.nick, type: this.types.mobile },
    { user: this.users.eva, type: this.types.home },
    { user: this.users.jack, type: this.types.mobile },
    { user: this.users.lee, type: this.types.mobile },
    { user: this.users.alan, type: this.types.home },
    { user: this.users.kate, type: this.types.work },
  ];
  private recentUsers: RecentUsers[]  = [
    { user: this.users.alan, type: this.types.home, time: this.time.setHours(21, 12)},
    { user: this.users.eva, type: this.types.home, time: this.time.setHours(17, 45)},
    { user: this.users.nick, type: this.types.mobile, time: this.time.setHours(5, 29)},
    { user: this.users.lee, type: this.types.mobile, time: this.time.setHours(11, 24)},
    { user: this.users.jack, type: this.types.mobile, time: this.time.setHours(10, 45)},
    { user: this.users.kate, type: this.types.work, time: this.time.setHours(9, 42)},
    { user: this.users.kate, type: this.types.work, time: this.time.setHours(9, 31)},
    { user: this.users.jack, type: this.types.mobile, time: this.time.setHours(8, 0)},
  ];

  getUsers(): Observable<any> {
    return observableOf(this.users);
  }

  getAdminUsers(){
    return this.http.get(this.user,this.httpoptions)
  }

  postAdminUsers(data){
    return this.http.post(this.user,data,this.httpoptions)
  }

  updateAdminUsers(data,username){
    return this.http.patch(this.user+'/'+username,data,this.httpoptions)
  }

  getContacts(): Observable<Contacts[]> {
    return observableOf(this.contacts);
  }

  getRecentUsers(): Observable<RecentUsers[]> {
    return observableOf(this.recentUsers);
  }

  assignRoles(data){
   return this.http.post(this.user +"/roles/"+"add",data,this.httpoptions)
  }
  getAgentRoles(){
    return this.http.get(this.roles,this.httpoptions)
  }

  assignClusterToAgent(data){
    return this.http.post(this.agent + "/update",data,this.httpoptions)

  }
  getAgents(){
    return this.http.get(this.agent,this.httpoptions)
  }
  getClusterManager(){
    return this.http.get(this.clusterManager,this.httpoptions)
  }




}
