import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "../../../../src/environments/environment";
import { runInThisContext } from "vm";
@Injectable({
  providedIn: "root",
})
export class StoreService {
  httpoptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json",
      responseType: "json",
      Authorization: "Bearer " + localStorage.getItem("ACCESS_TOKEN"),
    }),
  };

  stores: string = environment.link + "/stores";
  constructor(private http: HttpClient) {}
  getStores() {
    return this.http.get(this.stores, this.httpoptions);
  }
  getStoreById(id) {
    return this.http.get(this.stores + "/" + id, this.httpoptions);
  }

  getMeetingById(id) {
    return this.http.get(this.stores + "/meetings/" + id, this.httpoptions);
  }
  getStoreTable() {
    return this.http.get(this.stores + "/exportable/stores", this.httpoptions);
  }
  getStaticTable(val: number, params) {
    const query = "?page=" + val + "&limit=" + 20;
    return this.http.post(
      this.stores + "/static" + query,
      params,
      this.httpoptions
    );
  }
  getStaticTableForExport(val: number, params) {
    const query = "?page=" + val + "&limit=" + 0;
    return this.http.post(
      this.stores + "/static" + query,
      params,
      this.httpoptions
    );
  }
}
