import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders } from '@angular/common/http'
import {environment} from "../../../../src/environments/environment"


@Injectable({
  providedIn: 'root'
})
export class WorkflowService {

  workflowArray:any[]=[]
   httpoptions={
  headers : new HttpHeaders({
    'Content-Type': 'application/json',
    'responseType': 'json',
    Authorization:'Bearer ' +localStorage.getItem('ACCESS_TOKEN'),
})
  };
 
  addWorkflow:string=environment.link+"/workflows"
  constructor(private http:HttpClient) { }

  postWorkflowData(data){
    this.workflowArray=data
  }

  getWorkFlowData(){
    return this.workflowArray

  }

  postWorkflow(data){
    return this.http.post(this.addWorkflow,data,this.httpoptions)
  }
  getWorkflow(){
    return this.http.get(this.addWorkflow,this.httpoptions)
  }

  getWorkflowById(key){
    return this.http.get(this.addWorkflow +'/'+key,this.httpoptions)
  }

  postStep(data){
    return this.http.post(this.addWorkflow+"/step/"+"add",data, this.httpoptions)
  }
  assignFields(data){
    return this.http.post(this.addWorkflow+"/step/"+"fields/" +"assign",data, this.httpoptions)

  }
  deleteFields(data){
    return this.http.post(this.addWorkflow+"/step/"+"fields/" +"unassign",data, this.httpoptions)

  }
  deleteSteps(data){
    return this.http.post(this.addWorkflow+"/"+data.workflowKey+"/step/"+data.stepId+"/remove",this.httpoptions)
  }
  
  postFieldPosition(data){
    return this.http.post(this.addWorkflow +"/update/"+"position",data,this.httpoptions)
  }
  
}
