import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TypeService {

  public types:any  = [
   {
     name:"string", id:"1",

   },
   {
    name:"float", id:"2",
    
  },
  {name:"imageDoc", id:"3"},
  {name:"integer", id:"4"},
  {name:"image",id:"5"},
  {name:"doc",id:"6"},
  {name:"boolean", id:"7"},
  {name:"select", id:"8"},
  {name:"checkbox", id:"9"},
  {name:"multiselect",id:"10"},
  {name:"mobile",id:"11"},
  {name:"location",id:'12'},
  {name:"search",id:"13"},
  {name:"multiImage",id:"14"},
{name:"product", id:"15"},
{name:"swipe",id:"16"},
{name:"counter",id:"17"},
{name:"collapse",id:"18"},
{name:"price_counter",id:"19"}
  ];


  constructor() {}

  getTypes(){
    return this.types
  }
}
