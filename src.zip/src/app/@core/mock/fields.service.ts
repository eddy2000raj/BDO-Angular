import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders } from '@angular/common/http'
import {environment} from "../../../../src/environments/environment"



@Injectable({
  providedIn: 'root'
})
export class FieldsService {
  httpoptions={
    headers : new HttpHeaders({
      'Content-Type': 'application/json',
      'responseType': 'json',
      Authorization:'Bearer ' +localStorage.getItem('ACCESS_TOKEN'),
  })
    };
    addFields:string=environment.link+"/fields"
    addValidation:string=environment.link +"/validation"
    types:string= environment.link+"/utility/data-types";
  constructor(private http:HttpClient) { }

  postFields(data){
    return this.http.post(this.addFields,data,this.httpoptions);

  }

  getFields(){
    return this.http.get(this.addFields,this.httpoptions);
  }

  getFieldsByKeyName(id){
    return this.http.get(this.addFields +"/"+id,this.httpoptions);
  }

  postValidation(data){
    return this.http.post(this.addValidation+"/create", data , this.httpoptions)
  }

  getValidation(){
    return this.http.get(this.addValidation +"/all",this.httpoptions)
  }

  getFieldTypes(){
    return this.http.get(this.types,this.httpoptions);
  }

  getValidationById(id){
    return this.http.get(this.addValidation +"/"+id,this.httpoptions)
  }

  updateValidation(data){
    return this.http.post(this.addValidation+"/update",data,this.httpoptions)
  }
}
