import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders } from '@angular/common/http'
import {environment} from "../../../../src/environments/environment"
@Injectable({
  providedIn: 'root'
})
export class ClusterService {
  
  cluster:string=environment.link+"/clusters"
  httpoptions={
    headers : new HttpHeaders({
      'Content-Type': 'application/json',
      'responseType': 'json',
      Authorization:'Bearer ' +localStorage.getItem('ACCESS_TOKEN'),
  })
    };
  constructor(private http:HttpClient) { }

  postCluster(data){
    return this.http.post(this.cluster,data,this.httpoptions)

  }
  getCluster(){
    return this.http.get(this.cluster +"/all",this.httpoptions)
  }
}
