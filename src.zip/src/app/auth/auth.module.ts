import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgxAuthRoutingModule } from './auth-routing.module';
import { NbAuthModule } from '@nebular/auth';
import {
  NbAlertModule,
  NbButtonModule,
  NbCheckboxModule,
  NbInputModule,
  NbActionsModule,
  NbCardModule,
  NbDatepickerModule,
   NbIconModule,
  NbRadioModule,
  NbSelectModule,
  NbUserModule,
} from '@nebular/theme';
import { NgxLoginComponent } from './login/login.component';

  import { ThemeModule } from '../../app/@theme/theme.module';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ThemeModule,
    NbAlertModule,
    NbInputModule,
    NbButtonModule,
    NbCheckboxModule,
    NgxAuthRoutingModule,
    NbActionsModule,
    NbCardModule,
    NbDatepickerModule,
     NbIconModule,
    NbRadioModule,
    NbSelectModule,
    NbUserModule,
    NbAuthModule,
    ReactiveFormsModule,
  ],
  declarations: [
      NgxLoginComponent,
    // ... here goes our new components
  ],
})
export class NgxAuthModule {
}
