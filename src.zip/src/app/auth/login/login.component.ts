import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthService } from "../../auth.service";
import { Router } from "@angular/router";
import { HeaderService } from "../../header.service";
import { permissions } from "../../@core/data/permission.model";

@Component({
  selector: "ngx-login",
  styleUrls: ["./login.component.scss"],
  templateUrl: "./login.component.html",
})
export class NgxLoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;
  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private route: Router,
    private header: HeaderService
  ) {}
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ["", [Validators.required]],
      password: ["", [Validators.required]],
    });
  }
  login() {
    this.authService.LoginPost(this.loginForm.value).subscribe(
      (auth) => {

        if (auth["statusCode"] === 200) {
          this.authService.isloggedIn = true;
          this.authService.loggedInUser = auth["data"]["result"].token;
          localStorage.setItem("ACCESS_TOKEN", auth["data"]["result"].token);
          localStorage.setItem("username", this.loginForm.value.username);
          localStorage.setItem(
            "permission",
            JSON.stringify(auth["data"]["result"]["permissions"])
          );
          localStorage.setItem(
            "roles",
            JSON.stringify(auth["data"]["result"]["roles"])
          );
          this.header.showToast("success", "success", auth["message"]);
          const hidden = auth["data"]["result"]["permissions"].find(res=>res === permissions.CAN_CREATE_WORKFLOW)?true:false;
          if(hidden){
            this.route.navigate(["/pages/layout/workflow"]);
          }
          else{
            this.route.navigate(["/pages/store/storeInfo"]);
          }
        } else {
        }
      },
      (err) => {
        this.header.showToast("danger", "Try again!", err["statusText"]);
      }
    );
  }
}
