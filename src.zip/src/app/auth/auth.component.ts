import { Component, OnDestroy } from '@angular/core';
@Component({
  selector: 'nb-auth',
  styleUrls: ['./auth.component.scss'],
  template: `
  `,
})
export class NbAuthComponent implements OnDestroy {
  private alive = true;
  subscription: any;
  authenticated: boolean = false;
  token: string = '';
  // showcase of how to use the onAuthenticationChange method
  ngOnDestroy(): void {

  }
}