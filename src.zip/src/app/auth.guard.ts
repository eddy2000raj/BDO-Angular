import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree, Router, CanLoad } from '@angular/router';
import { Observable } from 'rxjs';
import {AuthService} from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanLoad {

  constructor(private authService: AuthService, private route: Router) {

  }
  canLoad(route: import('@angular/router').Route, segments: import('@angular/router').UrlSegment[]): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    const url: string = route.path;

    if (this.authService.isLoggedInUser()) {
      console.log('Url:' + url);
      return true;
    }
    this.authService.setRedirectUrl(url);
    this.route.navigate([this.authService.getLoginUrl()]);
    return false;
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const url: string = state.url;
    console.log('Url:' + url);
    if (this.authService.isLoggedInUser()) {
      return true;
    }
    this.authService.setRedirectUrl(url);
    this.route.navigate([this.authService.getLoginUrl()]);
    return false;
  }



}
