import { Component } from "@angular/core";

@Component({
  selector: "ngx-footer",
  styleUrls: ["./footer.component.scss"],
  template: `<div class="version">
    <strong><p>version:1.0.1</p></strong>
  </div>`,
})
export class FooterComponent {}
